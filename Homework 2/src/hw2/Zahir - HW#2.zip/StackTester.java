package hw2;

// Author: Zahir Choudhry

public class StackTester {
	public static void main(String[] args) {
		
		/* Array Stack test Code
		ArrayStack a1 = new ArrayStack(); // Create an empty array w 5 spots. size = 0
		//System.out.println(a1.size());
		a1.push(1.0);
		a1.push(2.0);
		a1.push(3.0);
		a1.push(4.0);
		a1.push(5.0);
		a1.push(6.0);
		//System.out.println(a1.size());
		System.out.println(a1.peek());
		System.out.println(a1.pop());
		System.out.println(a1.peek());
		System.out.println(a1.size());
		System.out.println(a1);
		*/
		
		/* Linked Stack Test Code
		LinkedStack Ls = new LinkedStack ();
		NumberNode n1 = new NumberNode(12);
		NumberNode n2 = new NumberNode(100);
		NumberNode n3 = new NumberNode(1000);
		NumberNode n4 = new NumberNode(120);
		OperatorNode n5 = new OperatorNode("%");

		//System.out.println(n1 instanceof NumberNode);
		
		//System.out.println(Ls.size());
		//System.out.println(Ls.isEmpty());
		Ls.push(n5);
		Ls.push(n1);
		//System.out.println(Ls.peek());
		//System.out.println(Ls.size());
		Ls.push(n2);
		Ls.push(n3);
		Ls.push(n4);
		//Ls.pop();
	
		//Ls.push(n2);
		//System.out.println(Ls.peek());
		//System.out.println(Ls.size());
		//System.out.println(Ls.peek());
		//Ls.pop();
		//System.out.println(Ls.size());
		//Ls.peek();
		
		//System.out.println("CHEESE");
		System.out.println(Ls); 
		*/
	}
}
